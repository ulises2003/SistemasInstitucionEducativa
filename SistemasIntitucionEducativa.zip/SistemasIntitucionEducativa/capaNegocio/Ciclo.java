/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaNegocio;

/**
 *
 * @author Usuario
 */
public class Ciclo {

    public Ciclo() {
        this.numeroC = "";
        this.inicioC = "";
        this.finC = "";
    }

    public Ciclo(String numeroC, String inicioC, String finC) {
        this.numeroC = numeroC;
        this.inicioC = inicioC;
        this.finC = finC;
    }
    
    private String numeroC;
    private String inicioC;
    private String finC;

    public String getNumeroC() {
        return numeroC;
    }

    public void setNumeroC(String numeroC) {
        this.numeroC = numeroC;
    }

    public String getInicioC() {
        return inicioC;
    }

    public void setInicioC(String inicioC) {
        this.inicioC = inicioC;
    }

    public String getFinC() {
        return finC;
    }

    public void setFinC(String finC) {
        this.finC = finC;
    }
     // propiedades
    public String Organizar()
    {  
       return "No esta implementado este metodo";
    }   

}
