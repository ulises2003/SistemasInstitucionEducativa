/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaNegocio;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Usuario
 */
public class PlanEstudio {

    public PlanEstudio() {
        this.codigo = "";
        this.fechaIn = null;
        this.fechaFin = null;
    }

    public PlanEstudio(String codigo, Date fechaIn, Date fechaFin) {
        this.codigo = codigo;
        this.fechaIn = fechaIn;
        this.fechaFin = fechaFin;
    }
    
    private String codigo;
    private Date fechaIn;
    private Date fechaFin;
    public ArrayList<Asignatura> tieneAsignatura= new ArrayList();

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public Date getFechaIn() {
        return fechaIn;
    }

    public void setFechaIn(Date fechaIn) {
        this.fechaIn = fechaIn;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }
    // propiedades
    public String Iniciar()
    {  
       return "No esta implementado este metodo";
    }   
    public String Terminar()
    {  
       return "No esta implementado este metodo";
    } 
}
