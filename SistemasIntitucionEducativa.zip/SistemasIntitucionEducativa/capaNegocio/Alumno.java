/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaNegocio;

import java.util.Date;

/**
 *
 * @author Usuario
 */
public class Alumno {

    public Alumno() {
        this.apellidos = "";
        this.nombres = "";
        this.codigo = "";
        this.fechaNac = null;
        this.ciclo ="";
    }
    public Alumno(String apellidos, String nombres, String codigo, Date fechaNac, String ciclo) {
        this.apellidos = apellidos;
        this.nombres = nombres;
        this.codigo = codigo;
        this.fechaNac = fechaNac;
        this.ciclo = ciclo;
    }
    
    private String apellidos;
    private String nombres;
    private String codigo;
    private Date fechaNac;
    private String ciclo;
    public Alumno tieneEscuelaProfesional;

    public String getApellidos() {
            return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public Date getFechaNac() {
        return fechaNac;
    }

    public void setFechaNac(Date fechaNac) {
        this.fechaNac = fechaNac;
    }

    public String getCiclo() {
        return ciclo;
    }

    public void setCiclo(String ciclo) {
        this.ciclo = ciclo;
    }
    
    // propiedades
    public String Matricularse()
    {  
       return "No esta implementado este metodo";
    }   
    public String Definir()
    {  
       return "No esta implementado este metodo";
    } 
}
