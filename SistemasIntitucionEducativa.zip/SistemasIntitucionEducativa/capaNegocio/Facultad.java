/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaNegocio;

/**
 *
 * @author Usuario
 */
public class Facultad {

    public Facultad() {
        this.codigo = "";
        this.nombre = "";
        this.decano = "";
    }

    public Facultad(String codigo, String nombre, String decano) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.decano = decano;
    }
    
    private String codigo ;
    private String nombre;
    private String decano;
    public EscuelaProfesional tieneEsculaProfesional;

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDecano() {
        return decano;
    }

    public void setDecano(String decano) {
        this.decano = decano;
    }
    // propiedades
    public String Distribuir()
    {  
       return "No esta implementado este metodo";
    }   
    public String Clasificar()
    {  
       return "No esta implementado este metodo";
    } 
    public String TomarDeciciones()
    {  
       return "No esta implementado este metodo";
    } 
}
