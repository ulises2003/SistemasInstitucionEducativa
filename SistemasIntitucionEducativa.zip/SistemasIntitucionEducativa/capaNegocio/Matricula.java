/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaNegocio;

import java.util.ArrayList;

/**
 *
 * @author Usuario
 */
public class Matricula {

    public Matricula() {
        this.periodoM = "";
        this.periodoV = "";
        this.DuracionC = "";
    }

    public Matricula(String periodoM, String periodoV, String DuracionC) {
        this.periodoM = periodoM;
        this.periodoV = periodoV;
        this.DuracionC = DuracionC;
    }
    
    private String periodoM;
    private String periodoV;
    private String DuracionC;
    public ArrayList<Catalago> tieneCatalogo= new ArrayList();
    public Alumno tieneMatricula;

    public String getPeriodoM() {
        return periodoM;
    }

    public void setPeriodoM(String periodoM) {
        this.periodoM = periodoM;
    }

    public String getPeriodoV() {
        return periodoV;
    }

    public void setPeriodoV(String periodoV) {
        this.periodoV = periodoV;
    }

    public String getDuracionC() {
        return DuracionC;
    }

    public void setDuracionC(String DuracionC) {
        this.DuracionC = DuracionC;
    }
    // propiedades
    public String Seleccionar()
    {  
       return "No esta implementado este metodo";
    }   
    public String Organizar()
    {  
       return "No esta implementado este metodo";
    } 
    
}
