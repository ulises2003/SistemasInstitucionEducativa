/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaNegocio;

import java.util.ArrayList;

/**
 *
 * @author Usuario
 */
public class Catalago {

    public Catalago() {
        this.codigo = "";
        this.cantidadCreditoM = "";
    }
    public Catalago(String codigo, String cantidadCreditoM) {
        this.codigo = codigo;
        this.cantidadCreditoM = cantidadCreditoM;
    }
  
    private String codigo;
    private String cantidadCreditoM;
    public ArrayList<Asignatura> tieneAsignatura= new ArrayList();
    public ArrayList<Matricula> tieneMatricula= new ArrayList();

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getCantidadCreditoM() {
        return cantidadCreditoM;
    }

    public void setCantidadCreditoM(String cantidadCreditoM) {
        this.cantidadCreditoM = cantidadCreditoM;
    }
    // propiedades
    public String OfreceAsig()
    {  
       return "No esta implementado este metodo";
    }   
    public String Matricular()
    {  
       return "No esta implementado este metodo";
    } 
}
