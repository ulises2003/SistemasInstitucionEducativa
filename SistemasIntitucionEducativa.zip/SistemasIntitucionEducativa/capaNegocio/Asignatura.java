/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaNegocio;

import java.util.ArrayList;

/**
 *
 * @author Usuario
 */
public class Asignatura {

    public Asignatura() {
        this.nombre = "";
        this.nroCreditos = 0;
        this.semestre = "";
        this.codigo = "";
    }
    
    public Asignatura(String nombre, int nroCreditos, String semestre, String codigo) {
        this.nombre = nombre;
        this.nroCreditos = nroCreditos;
        this.semestre = semestre;
        this.codigo = codigo;
    }
 
    private String nombre ;
    private int nroCreditos;
    private String semestre;
    private String codigo;
    public ArrayList<Catalago> tieneCatalogo= new ArrayList();
    public EscuelaProfesional pertenceEscuelaProfesional;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNroCreditos() {
        return nroCreditos;
    }

    public void setNroCreditos(int nroCreditos) {
        this.nroCreditos = nroCreditos;
    }

    public String getSemestre() {
        return semestre;
    }

    public void setSemestre(String semestre) {
        this.semestre = semestre;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    // propiedades
    public String Aprender()
    {  
       return "No esta implementado este metodo";
    }   

}
