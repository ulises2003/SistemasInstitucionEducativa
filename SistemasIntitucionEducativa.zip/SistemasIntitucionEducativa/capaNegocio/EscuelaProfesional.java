/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaNegocio;

import java.util.ArrayList;

/**
 *
 * @author Usuario
 */
public class EscuelaProfesional {

    public EscuelaProfesional() {
        this.codigo = "";
        this.nombre = "";
        this.director = "";
        this.sede = "";
    }

    public EscuelaProfesional(String codigo, String nombre, String director, String sede) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.director = director;
        this.sede = sede;
    }
    
    
    private String codigo ;
    private String nombre;
    private String director ;
    private String sede;
    public ArrayList<Facultad> tieneFacultad= new ArrayList();
    public Asignatura tieneAsignatura ;
    
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getSede() {
        return sede;
    }

    public void setSede(String sede) {
        this.sede = sede;
    }
    // propiedades
    public String Dirigir()
    {  
       return "No esta implementado este metodo";
    }   
    public String Organizar()
    {  
       return "No esta implementado este metodo";
    } 
    public String TomarDeciciones()
    {  
       return "No esta implementado este metodo";
    } 
}
